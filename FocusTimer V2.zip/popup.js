let timerInterval;
let timeLeft = 25 * 60;
let isRunning = false;
let isWorkMode = true;
let workDuration = 25;
let breakDuration = 5;

const timerDisplay = document.getElementById('timerDisplay');
const modeDisplay = document.getElementById('modeDisplay');
const startBtn = document.getElementById('startBtn');
const pauseBtn = document.getElementById('pauseBtn');
const resetBtn = document.getElementById('resetBtn');
const sessionsToday = document.getElementById('sessionsToday');
const siteInput = document.getElementById('siteInput');
const addSiteBtn = document.getElementById('addSiteBtn');
const siteList = document.getElementById('siteList');
const settingsPanel = document.getElementById('settingsPanel');
const workMinutesInput = document.getElementById('workMinutes');
const breakMinutesInput = document.getElementById('breakMinutes');

// 초기화
chrome.storage.local.get(['timeLeft', 'isRunning', 'isWorkMode', 'sessionsToday', 'blockedSites', 'workDuration', 'breakDuration'], (data) => {
  timeLeft = data.timeLeft || 25 * 60;
  isRunning = data.isRunning || false;
  isWorkMode = data.isWorkMode !== undefined ? data.isWorkMode : true;
  workDuration = data.workDuration || 25;
  breakDuration = data.breakDuration || 5;
  
  workMinutesInput.value = workDuration;
  breakMinutesInput.value = breakDuration;
  
  updateDisplay();
  updateSessionsDisplay(data.sessionsToday || 0);
  displayBlockedSites(data.blockedSites || []);
  
  if (isRunning) {
    startBtn.style.display = 'none';
    pauseBtn.style.display = 'inline-block';
    settingsPanel.classList.add('disabled');
  }
});

function updateDisplay() {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  modeDisplay.textContent = isWorkMode ? '🔥 작업 모드' : '☕ 휴식 모드';
}

function updateSessionsDisplay(count) {
  sessionsToday.textContent = count;
}

// 시간 설정 변경 이벤트
workMinutesInput.addEventListener('change', () => {
  const value = parseInt(workMinutesInput.value);
  if (value >= 1 && value <= 120) {
    workDuration = value;
    chrome.storage.local.set({ workDuration });
    if (isWorkMode && !isRunning) {
      timeLeft = workDuration * 60;
      chrome.storage.local.set({ timeLeft });
      chrome.runtime.sendMessage({ action: 'updateDuration', workDuration, breakDuration });
      updateDisplay();
    }
  } else {
    workMinutesInput.value = workDuration;
  }
});

breakMinutesInput.addEventListener('change', () => {
  const value = parseInt(breakMinutesInput.value);
  if (value >= 1 && value <= 60) {
    breakDuration = value;
    chrome.storage.local.set({ breakDuration });
    if (!isWorkMode && !isRunning) {
      timeLeft = breakDuration * 60;
      chrome.storage.local.set({ timeLeft });
      chrome.runtime.sendMessage({ action: 'updateDuration', workDuration, breakDuration });
      updateDisplay();
    }
  } else {
    breakMinutesInput.value = breakDuration;
  }
});

startBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'start' });
  startBtn.style.display = 'none';
  pauseBtn.style.display = 'inline-block';
  settingsPanel.classList.add('disabled');
});

pauseBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'pause' });
  pauseBtn.style.display = 'none';
  startBtn.style.display = 'inline-block';
  settingsPanel.classList.remove('disabled');
});

resetBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'reset' });
  pauseBtn.style.display = 'none';
  startBtn.style.display = 'inline-block';
  settingsPanel.classList.remove('disabled');
});

addSiteBtn.addEventListener('click', () => {
  const site = siteInput.value.trim();
  if (site) {
    chrome.runtime.sendMessage({ action: 'addSite', site }, () => {
      siteInput.value = '';
      chrome.storage.local.get(['blockedSites'], (data) => {
        displayBlockedSites(data.blockedSites || []);
      });
    });
  }
});

function displayBlockedSites(sites) {
  siteList.innerHTML = '';
  sites.forEach(site => {
    const div = document.createElement('div');
    div.className = 'site-item';
    div.innerHTML = `
      <span>${site}</span>
      <button class="remove-btn" data-site="${site}">삭제</button>
    `;
    siteList.appendChild(div);
  });

  document.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const site = e.target.getAttribute('data-site');
      chrome.runtime.sendMessage({ action: 'removeSite', site }, () => {
        chrome.storage.local.get(['blockedSites'], (data) => {
          displayBlockedSites(data.blockedSites || []);
        });
      });
    });
  });
}

// 백그라운드로부터 업데이트 받기
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'updateTimer') {
    timeLeft = message.timeLeft;
    isWorkMode = message.isWorkMode;
    updateDisplay();
  } else if (message.action === 'sessionComplete') {
    updateSessionsDisplay(message.sessionsToday);
  }
});

// 1초마다 상태 동기화
setInterval(() => {
  chrome.storage.local.get(['timeLeft', 'isWorkMode'], (data) => {
    timeLeft = data.timeLeft || timeLeft;
    isWorkMode = data.isWorkMode !== undefined ? data.isWorkMode : isWorkMode;
    updateDisplay();
  });
}, 1000);