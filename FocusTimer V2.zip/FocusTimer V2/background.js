let timerInterval;
let timeLeft = 25 * 60;
let isRunning = false;
let isWorkMode = true;
let sessionsToday = 0;
let blockedSites = [];
let workDuration = 25;
let breakDuration = 5;

// 초기화
chrome.storage.local.get(['timeLeft', 'isRunning', 'isWorkMode', 'sessionsToday', 'blockedSites', 'lastDate', 'workDuration', 'breakDuration'], (data) => {
  const today = new Date().toDateString();
  
  if (data.lastDate !== today) {
    sessionsToday = 0;
    chrome.storage.local.set({ sessionsToday: 0, lastDate: today });
  } else {
    sessionsToday = data.sessionsToday || 0;
  }
  
  workDuration = data.workDuration || 25;
  breakDuration = data.breakDuration || 5;
  timeLeft = data.timeLeft || workDuration * 60;
  isRunning = data.isRunning || false;
  isWorkMode = data.isWorkMode !== undefined ? data.isWorkMode : true;
  blockedSites = data.blockedSites || [];
  
  if (isRunning) {
    startTimer();
  }
  
  updateBlockingRules();
});

function startTimer() {
  if (timerInterval) return;
  
  isRunning = true;
  chrome.storage.local.set({ isRunning: true });
  
  timerInterval = setInterval(() => {
    timeLeft--;
    chrome.storage.local.set({ timeLeft });
    
    chrome.runtime.sendMessage({
      action: 'updateTimer',
      timeLeft,
      isWorkMode
    }).catch(() => {});
    
    if (timeLeft <= 0) {
      completeSession();
    }
  }, 1000);
}

function pauseTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  isRunning = false;
  chrome.storage.local.set({ isRunning: false });
}

function resetTimer() {
  pauseTimer();
  timeLeft = isWorkMode ? workDuration * 60 : breakDuration * 60;
  chrome.storage.local.set({ timeLeft });
  
  chrome.runtime.sendMessage({
    action: 'updateTimer',
    timeLeft,
    isWorkMode
  }).catch(() => {});
}

function completeSession() {
  pauseTimer();
  
  if (isWorkMode) {
    sessionsToday++;
    chrome.storage.local.set({ sessionsToday });
    
    chrome.runtime.sendMessage({
      action: 'sessionComplete',
      sessionsToday
    }).catch(() => {});
    
    // Chrome 알림 표시
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: '작업 세션 완료! 🎉',
      message: `휴식 시간입니다. ${breakDuration}분간 쉬세요!`,
      priority: 2
    });
  } else {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon.png',
      title: '휴식 완료! 💪',
      message: '다시 집중할 시간입니다!',
      priority: 2
    });
  }
  
  isWorkMode = !isWorkMode;
  timeLeft = isWorkMode ? workDuration * 60 : breakDuration * 60;
  chrome.storage.local.set({ isWorkMode, timeLeft });
  
  chrome.runtime.sendMessage({
    action: 'updateTimer',
    timeLeft,
    isWorkMode
  }).catch(() => {});
  
  updateBlockingRules();
}

function updateBlockingRules() {
  if (!isRunning || !isWorkMode || blockedSites.length === 0) {
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1]
    }).catch(() => {});
    return;
  }
  
  const urlFilters = blockedSites.map(site => `*://*.${site}/*`);
  
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1],
    addRules: [{
      id: 1,
      priority: 1,
      action: { type: 'redirect', redirect: { url: 'data:text/html;charset=utf-8,<h1 style="text-align:center;margin-top:20%;font-family:sans-serif;"">🚫 작업 시간입니다! 집중하세요!</h1>' } },
      condition: { urlFilter: urlFilters.join('|'), resourceTypes: ['main_frame'] }
    }]
  }).catch(() => {});
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'start') {
    startTimer();
    updateBlockingRules();
  } else if (message.action === 'pause') {
    pauseTimer();
    updateBlockingRules();
  } else if (message.action === 'reset') {
    resetTimer();
  } else if (message.action === 'updateDuration') {
    workDuration = message.workDuration;
    breakDuration = message.breakDuration;
    chrome.storage.local.set({ workDuration, breakDuration });
  } else if (message.action === 'addSite') {
    if (!blockedSites.includes(message.site)) {
      blockedSites.push(message.site);
      chrome.storage.local.set({ blockedSites });
      updateBlockingRules();
    }
    sendResponse();
  } else if (message.action === 'removeSite') {
    blockedSites = blockedSites.filter(s => s !== message.site);
    chrome.storage.local.set({ blockedSites });
    updateBlockingRules();
    sendResponse();
  }
  return true;
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.isRunning) {
    updateBlockingRules();
  }
});